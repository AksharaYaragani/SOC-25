class Solution {
    public static void dfs(int node, boolean vis[], ArrayList<ArrayList<Integer>> adj) {
        vis[node] = true;
        for(Integer it: adj.get(node)) {
            if(vis[it] == false) {
                dfs(it, vis, adj);
            }
        }
    }
    public int countComponents(int n, int[][] edges) {
         ArrayList<ArrayList<Integer>> lt=new ArrayList<>();
        for (int i = 0; i < n; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
    lt.get(v).add(u);       
}
       boolean vis[] = new boolean[n];
       int cnt = 0;
        for (int i = 0; i < n; i++) {
            if (!vis[i]) {
                dfs(i, vis, lt);
                cnt++; 
            }
        }
        return cnt;
    }
}