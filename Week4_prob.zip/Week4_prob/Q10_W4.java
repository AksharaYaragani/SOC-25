class Solution {
    public static void dfs(int u,boolean visited[],Stack <Integer> st,ArrayList<ArrayList<Integer>> adj){
        visited[u]=true;
        for(int it:adj.get(u)){
         if(!visited[it])
            dfs(it,visited,st,adj);
        }
    st.push(u);
    }
    public static ArrayList<Integer> findOrder(int n, int[][] prerequisites) {
       ArrayList<ArrayList<Integer> > list=new ArrayList<>();
        for (int i = 0; i < n; i++) {
           list.add(new ArrayList<>());
        }
    for (int i = 0; i < prerequisites.length; i++) {
    int u = prerequisites[i][0];
    int v = prerequisites[i][1];
    list.get(v).add(u);      
}
        ArrayList<Integer> lt=new ArrayList<>();
        Stack<Integer> st=new Stack<>();
        boolean[] vis=new boolean[n];
    for(int i = 0; i<n; i++){
      if(!vis[i])    
         dfs(i, vis, st,list);
}
 while(!st.empty()) {
      lt.add(st.peek());
      st.pop();
   }
   return lt;
    }
}
    