class Solution {
    public static void dfs(int u,boolean visited[],Stack <Integer> st,ArrayList<ArrayList<Integer>> adj){
        visited[u]=true;
        for(int it:adj.get(u)){
         if(!visited[it])
            dfs(it,visited,st,adj);
        }
    st.push(u);
    }
    public static ArrayList<Integer> topoSort(int V, int[][] edges) {
        ArrayList<ArrayList<Integer> > list=new ArrayList<>();
        for (int i = 0; i < V; i++) {
           list.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    list.get(u).add(v);      
}

        ArrayList<Integer> lt=new ArrayList<>();
        Stack<Integer> st=new Stack<>();
        boolean[] vis=new boolean[V];
    for(int i = 0; i<V; i++){
      if(!vis[i])    
         dfs(i, vis, st,list);
}
 while(!st.empty()) {
      lt.add(st.peek());
      st.pop();
   }
   return lt;
    }
}