class Solution {
    int[] parent;
    public void union(int i, int j) {
        int irep = find(i);
        int jrep = find(j);
        parent[irep] = jrep;
    }
    public int find(int i) {
        if (parent[i] == i) {
            return i;
        }
        return find(parent[i]);
    }
    public int countComponents(int n, int[][] edges) {
          parent = new int[n];
        for (int i = 0; i < n; i++) {
            parent[i] = i;
        }
          for(int i=0;i<edges.length;i++){
            union(edges[i][0],edges[i][1]);
          }
         
       Set<Integer> uniqueParents = new HashSet<>();
        for (int i = 0; i < n; i++) {
            uniqueParents.add(find(i));
        }
        return uniqueParents.size();
    

    }
}