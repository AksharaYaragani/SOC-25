class Solution {
      public static boolean bfs(int start,boolean vis[], ArrayList<ArrayList<Integer>> adj) {
         Queue < int[] > q = new LinkedList < > ();
        q.add(new int[]{start,-1});
        vis[start] = true;
        while (!q.isEmpty()) {
            int[] front=q.poll();
            int node = front[0];
            int par = front[1];
            for (int i = 0; i < adj.get(node).size(); i++) {
            int it = adj.get(node).get(i);
          if (!vis[it]) {
            vis[it] = true;
              q.add(new int[]{it,node});
    }
    else if(par !=it) return true;
}
    }
    return false;

    }
    public boolean isCycle(int V, int[][] edges) {
        // Code here
      ArrayList<ArrayList<Integer> > lt=new ArrayList<>();
        for (int i = 0; i < V; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
    lt.get(v).add(u);       
}
      boolean[] vis = new boolean[V];
       for(int i=0;i<V;i++){
           if(!vis[i]){
               if(bfs(i,vis,lt)) return true;
           }
       }
       return false;
}
}