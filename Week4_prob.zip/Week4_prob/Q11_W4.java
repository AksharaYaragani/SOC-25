// User function Template for Java

class Solution {
    static int minThrow(int N, int arr[]) {
        int[] board = new int[30];
        Arrays.fill(board, -1);
        for (int i = 0; i < 2 * N; i += 2) {
            int from = arr[i];
            int to = arr[i + 1];
            board[from - 1] = to - 1; 
        }
        boolean[] visited = new boolean[30];
        Queue<int[]> q = new LinkedList<>();
        visited[0] = true;
        q.add(new int[]{0, 0});  
        while (!q.isEmpty()) {
            int[] curr = q.poll();
            int v = curr[0];
            int dist = curr[1];
            if (v == 29)  
                return dist;
            for (int j = v + 1; j <= v + 6 && j < 30; ++j) {
                if (!visited[j]) {
                    visited[j] = true;
                    int dest = (board[j] != -1) ? board[j] : j;
                    q.add(new int[]{dest, dist + 1});
                }
            }
        }
        return -1; 
    }
}