class Solution {
    public void bfs(int start,ArrayList<ArrayList<Integer>> adj, boolean vis[] ) {
        Queue < Integer > q = new LinkedList < > ();
        q.add(start);
        vis[start] = true;
        while (!q.isEmpty()) {
            Integer node = q.poll();
            for (int i = 0; i < adj.get(node).size(); i++) {
            int it = adj.get(node).get(i);
          if (!vis[it]) {
            vis[it] = true;
              q.add(it);
    }
}
    }
  }
    public int countComponents(int n, int[][] edges) {
         ArrayList<ArrayList<Integer>> lt=new ArrayList<>();
        for (int i = 0; i < n; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
    lt.get(v).add(u);       
}
       boolean vis[] = new boolean[n];
       int cnt = 0;
        for (int i = 0; i < n; i++) {
            if (!vis[i]) {
                bfs(i,lt,vis);
                cnt++; 
            }
        }
        return cnt;
    }
}