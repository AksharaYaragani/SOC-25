class Solution {
      public static boolean dfs(int node,int parent ,boolean vis[], ArrayList<ArrayList<Integer>> adj) {
        vis[node] = true;
        for(Integer it: adj.get(node)) {
            if(vis[it] == false) {
                if(dfs(it,node, vis, adj)==true) return true;
            }
            else if(vis[it]==true && it !=parent) return true;
        }
        return false;
    }
    public boolean isCycle(int V, int[][] edges) {
        // Code here
      ArrayList<ArrayList<Integer> > lt=new ArrayList<>();
        for (int i = 0; i < V; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
    lt.get(v).add(u);       
}

       boolean vis[] = new boolean[V];
       for(int i=0;i<V;i++){
           if(!vis[i]){
               if(dfs(i,-1,vis,lt)) return true;
           }
           
       }
       return false;
}
}