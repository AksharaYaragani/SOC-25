class Pair {
    int first;
    int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }
}
class Solution {
      // Code here
     void bfs(int sr, int sc, int[][] vis, int[][] image,int initColor,int newColor){
        int n = image.length;
        int m = image[0].length;
        vis[sr][sc] = 1;
        image[sr][sc] = newColor;
        Queue<Pair> q = new LinkedList<Pair>();
        q.add(new Pair(sr, sc));
        while (!q.isEmpty()) {
            int row = q.peek().first;
            int col = q.peek().second;
            q.remove();
            int[] drow = { -1, 0, 1, 0 };
            int[] dcol = { 0, 1, 0, -1 };
            for (int i = 0; i < 4; i++) {
                int nrow = row + drow[i];
                int ncol = col + dcol[i];
                if (nrow >= 0 && nrow < n && ncol >= 0 && ncol < m &&
                        vis[nrow][ncol] == 0 && image[nrow][ncol] == initColor) {
                    vis[nrow][ncol] = 1;
                    image[nrow][ncol] = newColor;
                    q.add(new Pair(nrow, ncol));
                }
            }

        }
     }
    public int[][] floodFill(int[][] image, int sr, int sc, int newColor) {
        int initColor = image[sr][sc];
        if (initColor == newColor) return image; 
       int n = image.length;
        int m = image[0].length;
        int[][] vis = new int[n][m];
        bfs(sr, sc, vis, image,initColor, newColor);
        return image;
    }
}