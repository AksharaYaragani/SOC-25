class Solution {
    public int countPaths(int V, ArrayList<ArrayList<Integer>> adj, int source, int destination) {
        int[] indegree = new int[V];
        for (int u = 0; u < V; u++) {
            for (int v : adj.get(u)) {
                indegree[v]++;
            }
        }
        Queue<Integer> q = new LinkedList<>();
        for (int i = 0; i < V; i++) {
            if (indegree[i] == 0) {
                q.add(i);
            }
        }
        List<Integer> topoOrder = new ArrayList<>();
        while (!q.isEmpty()) {
            int node = q.poll();
            topoOrder.add(node);
            for (int neighbor : adj.get(node)) {
                indegree[neighbor]--;
                if (indegree[neighbor] == 0) {
                    q.add(neighbor);
                }
            }
        }
        int[] ways = new int[V];
        ways[source] = 1;
        for (int node : topoOrder) {
            for (int neighbor : adj.get(node)) {
                ways[neighbor] += ways[node];
            }
        }
        return ways[destination];
    }
}