class Solution {
    int rows, cols;
    boolean[][] visited;   
    public boolean containsCycle(char[][] grid) {
        rows = grid.length;
        cols = grid[0].length;
        visited = new boolean[rows][cols];
         for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (!visited[i][j]) {
                    if (dfs(grid, i, j, -1, -1, grid[i][j])) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
     public boolean dfs(char[][] grid, int x, int y, int fromX, int fromY, char target) {
        visited[x][y] = true;
        int[][] dirs = {{0,1},{1,0},{0,-1},{-1,0}};    
        for (int[] d : dirs) {
            int nx = x + d[0];
            int ny = y + d[1];
            if (nx < 0 || ny < 0 || nx >= rows || ny >= cols || grid[nx][ny] != target) continue;            
            if (nx == fromX && ny == fromY) continue; 
            if (visited[nx][ny]) return true;            
            if (dfs(grid, nx, ny, x, y, target)) return true;
        }
        return false;
    }
}
