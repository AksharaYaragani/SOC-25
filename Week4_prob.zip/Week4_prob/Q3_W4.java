class Solution {
    public List<List<Integer>> printGraph(int V, int edges[][]) {
        List<List<Integer>> lt=new ArrayList<>();
        for (int i = 0; i < V; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
    lt.get(v).add(u);       
}
        return lt;
}
}