class Solution {
    // Function to return Breadth First Search Traversal of given graph.
     ArrayList<Integer> bfsList = new ArrayList<>();
    boolean[] visited;
     private void bfsRecursive(ArrayList<ArrayList<Integer>> adj, Queue<Integer> q) {
        if (q.isEmpty())
            return;
        int node = q.poll();
        bfsList.add(node);

        for (int neighbor : adj.get(node)) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.add(neighbor);
            }
        }
        bfsRecursive(adj, q);
    }
    public ArrayList<Integer> bfs(ArrayList<ArrayList<Integer>> adj) {
        // code here
        int V = adj.size();
        visited = new boolean[V];
        Queue<Integer> q = new LinkedList<>();
        q.add(0);
        visited[0] = true;
        bfsRecursive(adj, q);
        return bfsList;
    }
}