class Solution {
    public static boolean dfs(int node,int[] pathvis ,boolean vis[], ArrayList<ArrayList<Integer>> adj) {
        vis[node] = true;
        pathvis[node]=1;
        for(Integer it: adj.get(node)) {
            if(vis[it] == false) {
                if(dfs(it,pathvis, vis, adj)==true) return true;
            }
            else if(pathvis[it]==1) return true;
        }
        pathvis[node]=0;
        return false;
    }

    public boolean isCyclic(int V, int[][] edges) {
        // code here
        ArrayList<ArrayList<Integer> > lt=new ArrayList<>();
        for (int i = 0; i < V; i++) {
           lt.add(new ArrayList<>());
        }
    for (int i = 0; i < edges.length; i++) {
    int u = edges[i][0];
    int v = edges[i][1];
    lt.get(u).add(v);      
}
       boolean vis[] = new boolean[V];
       int[] pathvis=new int[V];
       for(int i=0;i<V;i++){
           if(!vis[i]){
               if(dfs(i,pathvis,vis,lt)) return true;
           }
           
       }
       return false;

        
    }
}