class Solution {
    public List<Integer> preorderTraversal(TreeNode root) {
        List<Integer> lt=new ArrayList<>();
        preorder(root,lt);
        return lt;
    }
    public static void preorder(TreeNode root,List<Integer> lt){
        if(root==null) return;
        lt.add(root.val);
        preorder(root.left,lt);
        preorder(root.right,lt);
    }
}