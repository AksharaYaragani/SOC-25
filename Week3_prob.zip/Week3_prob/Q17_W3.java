import java.util.Scanner;
public class Q17_W3 {
    private static int makeEqualLength(StringBuilder str1, StringBuilder str2)
    {
        int len1 = str1.length();
        int len2 = str2.length();
        if (len1 < len2) {
            for (int i = 0; i < len2 - len1; i++) {
                str1.insert(0, '0');
            }
            return len2;
        }
        else if (len1 > len2) {
            for (int i = 0; i < len1 - len2; i++) {
                str2.insert(0, '0');
            }
        }
        return len1; 
    }
    private static int multiplySingleBit(int a, int b)
    {
        return a * b;
    }
    public static long multiply(String X, String Y)
    {
        int n = Math.max(X.length(), Y.length());
        X = String.format("%" + n + "s", X)
                .replace(' ', '0');
        Y = String.format("%" + n + "s", Y)
                .replace(' ', '0');
        if (n == 0)
            return 0;
        if (n == 1)
            return Integer.parseInt(X)
                * Integer.parseInt(Y);

        int fh = n / 2; 
        int sh = n - fh; 
        String Xl = X.substring(0, fh);
        String Xr = X.substring(fh);
        String Yl = Y.substring(0, fh);
        String Yr = Y.substring(fh);
        long P1 = multiply(Xl, Yl);
        long P2 = multiply(Xr, Yr);
        long P3 = multiply(Integer.toBinaryString(
                               Integer.parseInt(Xl, 2)
                               + Integer.parseInt(Xr, 2)),
                           Integer.toBinaryString(
                               Integer.parseInt(Yl, 2)
                               + Integer.parseInt(Yr, 2)));
        return P1 * (1L << (2 * sh))
            + (P3 - P1 - P2) * (1L << sh) + P2;
    }
     public static void main(String[] args)
    { Scanner sc = new Scanner(System.in);
        System.out.println("X1: ");
        String x1= sc.next();
        System.out.println("X2: ");
        String x2= sc.next();
        System.out.println(multiply(x1, x2));
        sc.close();
    }
}


