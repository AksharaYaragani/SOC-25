import java.util.Arrays;
import java.util.Scanner;
public class Q1_W3 {
    static int mergeOverlap(int[][] arr) {
        Arrays.sort(arr, (a, b) -> Integer.compare(a[0], b[0]));
        int resIdx = 0; 
        for (int i = 1; i < arr.length; i++) {
            if (arr[resIdx][1] >= arr[i][0])           
                arr[resIdx][1] = Math.max(arr[resIdx][1], arr[i][1]);
            else {            
                resIdx++;
                arr[resIdx] = arr[i];
            }
        }
        return (resIdx + 1);
    }

    public static void main(String[] args) {
        //int[][] arr = {{7, 8}, {1, 5}, {2, 4}, {4, 6}};
        Scanner sc= new Scanner(System.in);
        System.out.println("No.of intervals: ");
        int n=sc.nextInt();
        int[][] arr=new int[n][2];
        for(int i=0;i<n;i++){
            System.out.println("Start position: ");
            int n1=sc.nextInt();
             System.out.println("End position: ");
            int n2=sc.nextInt();
            arr[i][0]=n1;
            arr[i][1]=n2;
        }
        int newSize = mergeOverlap(arr);
        int Length=0; 
        for (int i = 0; i < newSize; i++) {
           Length= Math.max(Length,arr[i][1]-arr[i][0]);
        }
        System.out.println(Length);
        sc.close();
    }
}

