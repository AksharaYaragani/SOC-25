class Solution {
    public static int findPages(int[] arr, int k) {
        if (k > arr.length) return -1;

        int low = Arrays.stream(arr).max().getAsInt();
        int high = Arrays.stream(arr).sum(); 
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (isFeasible(arr, k, mid)) {
                result = mid;
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        return result;
    }

    private static boolean isFeasible(int[] arr, int k, int limit) {
        int students = 1, total = 0;
        for (int pages : arr) {
            if (total + pages > limit) {
                students++;
                total = pages;
                if (students > k) return false;
            } else {
                total += pages;
            }
        }
        return true;
    }
}
