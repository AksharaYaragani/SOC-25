import java.util.*;

public class Q4_W3{
    static class Building {
        int x, height;
        boolean isStart;

        public Building(int x, int height, boolean isStart) {
            this.x = x;
            this.height = height;
            this.isStart = isStart;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("No.of intervals: ");
        int n = sc.nextInt();

        List<Building> buildings = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.println("left : ");
            int left = sc.nextInt();
            System.out.println("right : ");
            int right = sc.nextInt();
            System.out.println("height : ");
            int height = sc.nextInt();
            buildings.add(new Building(left, height, true));
            buildings.add(new Building(right, height, false));
        }
        buildings.sort((a, b) -> {
            if (a.x != b.x)
                return a.x - b.x;
            if (a.isStart && b.isStart)
                return b.height - a.height;
            if (!a.isStart && !b.isStart)
                return a.height - b.height;
            return a.isStart ? -1 : 1;
        });

        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());
        maxHeap.add(0); 

        int prevX = 0;
        int prevMaxHeight = 0;
        int area = 0;

        for (Building b : buildings) {
            if (b.isStart) {
                maxHeap.add(b.height);
            } else {
                maxHeap.remove(b.height);
            }

            int currentMaxHeight = maxHeap.peek();
            if (currentMaxHeight != prevMaxHeight) {
                int width = b.x - prevX;
                area += width * prevMaxHeight;
                prevX = b.x;
                prevMaxHeight = currentMaxHeight;
            }
        }

        System.out.println(area);
    }
}
