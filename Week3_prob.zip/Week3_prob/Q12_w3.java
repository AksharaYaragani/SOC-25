class Solution {
    public int kthLargest(Node root, int k) {
       List<Integer> lt =new ArrayList<>();
       inorder(root,lt);
       return lt.get(lt.size()-k);
        
    }
     public static void inorder(Node root,List<Integer> lt){
       if(root==null) return;
       inorder(root.left,lt);
       lt.add(root.data);
       inorder(root.right,lt);
     }

}