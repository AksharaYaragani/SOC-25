class Solution {
    public List<Integer> postorderTraversal(TreeNode root) {
         List<Integer> lt=new ArrayList<>();
        postorder(root,lt);
        return lt;
 }
    public static void postorder(TreeNode root,List<Integer> lt){
        if(root==null) return;
        postorder(root.left,lt);
        postorder(root.right,lt);
         lt.add(root.val);
    }
}