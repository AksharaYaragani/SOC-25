class Solution {
    public TreeNode balanceBST(TreeNode root) {
        List<Integer> lt=new ArrayList<>();
        inorder(root,lt);
        int[] arr=new int[lt.size()];
        for(int i=0;i<lt.size();i++){
            arr[i]=lt.get(i);
        }
       return BST(arr,0,arr.length-1);
       }
     public static void inorder(TreeNode root,List<Integer> lt){
       if(root==null) return;
       inorder(root.left,lt);
       lt.add(root.val);
       inorder(root.right,lt);
       }
     public TreeNode BST(int[] nums,int low,int high){
        if (low > high) return null;
        int mid=(low+high)/2;
        TreeNode root=new TreeNode(nums[mid]);
        root.left= BST(nums,low,mid-1);
        root.right=BST(nums,mid+1,high);
        return root;
        }     
        }