import java.util.Scanner;
                              // Time Complexity = O(N^2);
                              // Space complexity = O(1);
public class SelectionSort {
    public static int[] sorting(int[] arr){
        for(int i=0;i<arr.length;i++){
            int minind=i;
            for(int j=i+1;j<arr.length-1;j++){
                if(arr[j]<arr[minind]) minind=j;
            }
            int temp=arr[i];
            arr[i]=arr[minind];
            arr[minind]=temp;
        }
        return arr;
    }
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         System.out.println("No. of testcases: ");
         int n = sc.nextInt();
         for(int i=0;i<n;i++){
            System.out.println("No. of values in array in " +"Tescase "+ (i+1) );
            int n2=sc.nextInt();
             int[] arr = new int[n2];
            System.out.println("Give values in the array: ");
            for(int j=0;j<n2;j++){
                arr[j]=sc.nextInt();
            }
            sorting(arr);
            System.out.println("Sorted array: ");
            for(int k=0;k<n2;k++){
            System.out.print(arr[k] + " ");
         }
         System.out.println("");
         }
         sc.close();
        }
}
