class Solution {
    public int[] intersection(int[] nums1, int[] nums2) {
        Arrays.sort(nums1);
        Arrays.sort(nums2);
    int left=0;
    int right=0;
    List<Integer> lt=new ArrayList<>();
     while(left<nums1.length && right<nums2.length){
        if(nums1[left]==nums2[right]){
          if (lt.isEmpty() || lt.get(lt.size() - 1) != nums1[left]) {
                    lt.add(nums1[left]);
                }
         left++;
         right++;
        }
        else if (nums1[left] < nums2[right]) {
                left++;
            } else {
                right++;
            }
     }
     
     int[] arr =new int[lt.size()]; 
     int i = 0;
        for (int num : lt) {
            arr[i++] = num;
        }
     return arr;
    }
}