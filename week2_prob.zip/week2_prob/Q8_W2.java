class Solution {
    public void sortColors(int[] nums) {
        int cnt1=0;
        int cnt2=0;
        int cnt3=0;
       for(int i=0;i<nums.length;i++){
        if(nums[i]==0) cnt1++;
        else if(nums[i]==1) cnt2++;
        else cnt3++;
       }
       for(int i=0;i<cnt1+cnt2+cnt3;i++){
        if(i<cnt1) nums[i]=0;
        else if(i<cnt1+cnt2) nums[i]=1;
        else nums[i]=2;
       }
    }
}