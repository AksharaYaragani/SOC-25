class Solution {
    public int noOf1Bits(int n){
        int cnt=0;
        while(n>1){
            cnt=cnt+(n&1);
            n=(n>>1);
        }
        if(n==1) cnt=cnt+1;
        return cnt;
    }
    public int[] sortByBits(int[] arr) {
        int nums[]=new int[arr.length];
       for(int i=0;i<arr.length;i++){
        nums[i]=noOf1Bits(arr[i])*10001 +arr[i];
       }
       Arrays.sort(nums);
        for (int i = 0; i < nums.length; i++) {
            nums[i] %= 10001;
        }
        return nums;
    }
}