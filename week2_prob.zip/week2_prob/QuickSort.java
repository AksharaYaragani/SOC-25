import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
                             // TimeComp-->O(NlogN) , Spacecomp-->O(N)
public class QuickSort {
    static int partition(List<Integer> arr, int low, int high) {
        int pivot = arr.get(low);
        int i = low;
        int j = high;

        while (i < j) {
            while (arr.get(i) <= pivot && i <= high - 1) {
                i++;
            }

            while (arr.get(j) > pivot && j >= low + 1) {
                j--;
            }
            if (i < j) {
                int temp = arr.get(i);
                arr.set(i, arr.get(j));
                arr.set(j, temp);
            }
        }
        int temp = arr.get(low);
        arr.set(low, arr.get(j));
        arr.set(j, temp);
        return j;
    }

    static void qs(List<Integer> arr, int low, int high) {
        if (low < high) {
            int pIndex = partition(arr, low, high);
            qs(arr, low, pIndex - 1);
            qs(arr, pIndex + 1, high);
        }
    }
    public static List<Integer> quickSort(List<Integer> arr) {
        // Write your code here.
        qs(arr, 0, arr.size() - 1);
        return arr;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         System.out.println("No. of testcases: ");
         int n = sc.nextInt();
         for(int i=0;i<n;i++){
            System.out.println("No. of values in array in " +"Tescase "+ (i+1) );
            int n2=sc.nextInt();
             int[] arr = new int[n2];
            System.out.println("Give values in the array: ");
            for(int j=0;j<n2;j++){
                arr[j]=sc.nextInt();
            }
             List<Integer> arrList = new ArrayList<>();
            for(int y=0;y<n2;y++){
                arrList.add(arr[y]);
            }
            quickSort(arrList);
            for (int x = 0; x < arrList.size(); x++) {
                arr[x] = arrList.get(x);
            }
            System.out.println("Sorted array: ");
            for(int k=0;k<n2;k++){
            System.out.print(arr[k] + " ");
         }
         System.out.println("");
         }
         sc.close();
    }
}
