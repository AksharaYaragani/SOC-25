import java.util.Scanner;
                             // Time complexity =O(N^2)  , Space complexity =  O(1);
public class InsertionSort {
    public static void sorting(int[] arr){
        for(int i=0;i<arr.length;i++){
            for(int j=i;j>0;j--){
              if(arr[j]<arr[j-1]){
                int temp= arr[j];
                arr[j]=arr[j-1];
                arr[j-1]=temp;
              }
            }
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         System.out.println("No. of testcases: ");
         int n = sc.nextInt();
         for(int i=0;i<n;i++){
            System.out.println("No. of values in array in " +"Tescase "+ (i+1) );
            int n2=sc.nextInt();
             int[] arr = new int[n2];
            System.out.println("Give values in the array: ");
            for(int j=0;j<n2;j++){
                arr[j]=sc.nextInt();
            }
            sorting(arr);
            System.out.println("Sorted array: ");
            for(int k=0;k<n2;k++){
            System.out.print(arr[k] + " ");
         }
         System.out.println("");
         }
         sc.close();
    }
}
