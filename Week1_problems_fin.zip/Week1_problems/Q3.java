class Solution {
    public int majorityElement(int[] nums) {
        int cnt=0;
        int elm=Integer.MIN_VALUE;
        for(int i=0;i<nums.length;i++){
          if(cnt==0){
            cnt++;
            elm=nums[i];
          }
          else if (nums[i]==elm) cnt++;
          else cnt--;
        }
    cnt = 0;
    for (int i = 0; i < nums.length; i++) {
      if (nums[i] == elm)
        cnt++;
        }
        if(cnt> nums.length/2  ){
             return elm;
    }
     return -1;
}
}