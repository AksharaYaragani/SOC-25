class Solution {
    public void merge(int[] nums1, int m, int[] nums2, int n) {
        int high1 = m - 1;       
        int high2 = n - 1;         
        int high3 = m + n - 1;      

        while (high1 >= 0 && high2 >= 0) {
            if (nums1[high1] > nums2[high2]) {
                nums1[high3] = nums1[high1];
                high3--;
                high1--;
            } else {
                nums1[high3] = nums2[high2];
                high3--;
                high2--;
            }
        }
        while (high2 >= 0) {
            nums1[high3] = nums2[high2];
            high3--;
            high2--;
        }
    }
}