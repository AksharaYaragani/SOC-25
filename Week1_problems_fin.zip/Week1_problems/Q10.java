class Solution {
    public boolean isSubsequence(String s, String t) {
        int low1=0;
        int low2=0;
        int cnt=0;
        if(s.length()==0) return true;
        for(int i=low2;i<t.length();i++){
        if(s.charAt(low1)==t.charAt(i)){
               cnt++; 
               if(low1<s.length()-1){
                low1++;
               }
            }
        }
        if(cnt==s.length()) return true;
        else return false;
}
}